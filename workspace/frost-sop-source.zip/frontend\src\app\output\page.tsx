export default function OutputPage() {
  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-[#0F172A]">产出文档</h1>
        <p className="text-sm text-[#64748B] mt-1">
          任务执行产出的文档、代码和报告
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[
          { name: "需求分析文档", type: "文档", date: "2026-06-24", status: "completed" },
          { name: "系统架构设计", type: "文档", date: "2026-06-24", status: "completed" },
          { name: "代码实现", type: "代码", date: "2026-06-24", status: "completed" },
          { name: "测试报告", type: "报告", date: "2026-06-24", status: "completed" },
          { name: "部署交付文档", type: "文档", date: "2026-06-24", status: "completed" },
        ].map((item, i) => (
          <div
            key={i}
            className="bg-white border border-[#E2E8F0] rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="font-medium text-sm text-[#0F172A]">{item.name}</div>
                <div className="text-xs text-[#64748B] mt-1">
                  {item.type} · {item.date}
                </div>
              </div>
              <span className="text-xs bg-green-50 text-[#22C55E] px-2 py-0.5 rounded-full font-medium">
                {item.status === "completed" ? "已完成" : item.status}
              </span>
            </div>
            <div className="mt-3 flex gap-2">
              <button className="text-xs text-[#3B82F6] hover:underline">查看</button>
              <button className="text-xs text-[#64748B] hover:underline">下载</button>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center text-sm text-[#64748B] py-4">
        连接后端后，此处将展示真实产出文件列表
      </div>
    </div>
  );
}
